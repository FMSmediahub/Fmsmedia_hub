const fs = require('fs');
const path = require('path');
const root = process.cwd();
const www = path.join(root, 'www');
fs.mkdirSync(www, { recursive: true });
const source = path.join(root, 'index.html');
const destination = path.join(www, 'index.html');
if (fs.existsSync(source)) {
  fs.copyFileSync(source, destination);
  console.log('Copied root index.html into www/');
} else if (!fs.existsSync(destination)) {
  fs.writeFileSync(destination, '<!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1"></head><body><h1>FMSmedia Hub</h1><p>Add your website index.html to the repository root.</p></body></html>');
  console.warn('No index.html found; created temporary placeholder.');
}
