# Privacy policy draft — FMSmedia Hub

**Draft only. Review and complete before publishing.**

Last updated: [insert date]

FMSmedia Hub is a creative-media services showcase and project-request prototype published by FMSmedia.

## Information entered by users
The prototype's project form asks for a name, contact details, service choice and project description. In the current version, this information is used to prepare a request message locally on the device for the user to copy. The form does not submit the request to an FMSmedia server.

## Data collection, sharing and retention
[Confirm the final app and any third-party SDKs, hosting, analytics, crash reporting, or external links. Describe whether any information is collected, transmitted, shared, or retained. Do not publish this draft until these statements have been verified.]

## Contact
Privacy questions: [insert official FMSmedia email address]

## Changes
This policy may be updated when app features or data practices change.
