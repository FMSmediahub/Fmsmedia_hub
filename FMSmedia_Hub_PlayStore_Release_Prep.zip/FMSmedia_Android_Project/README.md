# FMSmedia Hub — Android build starter

**Brand:** luxury black and gold  |  **App ID:** `com.fmsmedia.hub`

## Project status

- [x] Mobile-friendly HTML prototype in `www/`
- [x] PWA manifest and offline cache starter
- [x] Black/gold icon assets
- [x] Capacitor configuration
- [x] Cloud workflow for a debug APK and release-bundle build validation
- [ ] Build verified on CI (not yet run)
- [ ] Install and test on a real Android phone
- [ ] Release signing key created and safely backed up
- [ ] Signed AAB generated
- [ ] Play Console developer account and app record completed
- [ ] Store listing, privacy policy, declarations, testing and review completed

**No APK or Play-ready signed AAB has been built yet.** The CI release AAB is an unsigned validation artifact, not ready to upload to Google Play.

## Build from a computer

1. Install Node.js LTS, Java 17, Android Studio and Android SDK.
2. Unzip the project and open a terminal in this project folder.
3. Run:
   ```bash
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
4. In Android Studio, wait for Gradle sync, connect an Android phone with USB debugging or use an emulator, then run the app.
5. For a test APK, choose **Build > Build APK(s)**. Install it and test all screens, form, links, app navigation/back behavior, and offline startup.
6. For a signed Play release, choose **Build > Generate Signed Bundle / APK > Android App Bundle**. Create/use a release keystore, sign the bundle, and keep the keystore plus passwords securely backed up. Never send the keystore/passwords in chat or commit them to GitHub.

## Build from an Android phone using GitHub Actions

1. Create/sign in to GitHub. Create a repository named `fmsmedia-hub`.
2. Upload all files and folders from this ZIP, including `.github/workflows/build-android-apk.yml`.
3. Open the repo's **Actions** tab and run **Build FMSmedia Hub Android test APK and release bundle** (or push to `main`).
4. Wait for the workflow to finish. Open the successful run and download the artifact **FMSmedia-Hub-Android-builds**. Extract it: it contains a debug APK for device testing and an unsigned release AAB for build validation.
5. On your Android phone, install the debug APK. If Android asks, allow install-from-this-source temporarily for the file you built, then disable it again.

### Important Play Store release requirement

Google Play requires new apps and updates to target **Android 16 / API 36 or higher from August 31, 2026**. This starter uses Capacitor 7 and has not been verified to meet that target yet. Before submission, upgrade to a compatible Capacitor/Android build configuration and confirm the generated app's target SDK is API 36 or newer. The workflow installs SDK 36 but does not itself guarantee that the app targets API 36.

## Prototype limitations to fix/disclose before publishing

- Portfolio tiles are placeholders; add genuine approved projects/media.
- Project form prepares text locally for copying; it does not submit to a server or automatically send to FMSmedia.
- Planned app-suite entries are placeholders, not active apps.
- Add a hosted privacy policy and confirm actual data practices before completing Play Console declarations.
- Review contact details, external links, accessibility, screen-size behavior, and offline mode.

## Google Play release sequence

1. Register/verify the Play Console developer account and complete identity verification.
2. Create app entry: **FMSmedia Hub**, default language English, app, free/paid decision.
3. Complete store listing: short/full description, icon, feature graphic, phone screenshots, category, contact details.
4. Complete App content: privacy policy, data safety, ads, app access, content rating, target audience and any applicable declarations.
5. Upload a **signed AAB** to an appropriate testing track.
6. Test on real devices; resolve crashes and policy issues. New personal accounts may have specific closed-testing requirements—check the exact requirement shown in Play Console for your account.
7. Apply for production access if required, then submit production release for review.

## Next step for this project

Start with GitHub cloud build from your Android phone. The build will tell us whether the current prototype packages successfully and provide an APK to install and test. After that, upgrade/verify the Android target SDK and prepare the signed release.
