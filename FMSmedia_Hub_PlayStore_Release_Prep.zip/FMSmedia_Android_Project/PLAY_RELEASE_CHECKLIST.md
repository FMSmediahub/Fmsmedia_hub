# FMSmedia Hub — Pre-Play release checklist

## Build and device testing
- [ ] CI run succeeds; download debug APK
- [ ] Install on Android device and launch from app icon
- [ ] Home/services/portfolio/apps sections display and navigate
- [ ] Project form validation works; generated text is correct
- [ ] Copy request works or manual select/copy fallback is usable
- [ ] External links open correctly (if present)
- [ ] Android back button behaves sensibly
- [ ] Rotate/resize and test small screen; check keyboard does not hide form actions
- [ ] Offline startup works; no misleading claims about online-only functions
- [ ] No crashes, broken images, placeholder errors, or console errors
- [ ] Replace demo/placeholder portfolio and app-suite claims with accurate content

## Release setup
- [ ] Confirm target SDK is API 36+ (required for new apps/updates from Aug 31, 2026)
- [ ] Confirm app version/version code and package ID `com.fmsmedia.hub`
- [ ] Create release keystore and secure backup (do not share)
- [ ] Generate and verify signed Android App Bundle (.aab)
- [ ] Play Console account identity verification complete
- [ ] Privacy policy hosted and reachable; actual app data practices reviewed
- [ ] Data safety form, ads declaration, content rating, target audience and app access complete
- [ ] Store assets: 512x512 app icon, feature graphic (1024x500), phone screenshots, description
- [ ] Internal/closed testing track uploaded and testers recruited as Play Console requires
- [ ] Fix all feedback; production access and review submitted

## Current functionality disclosure
The prototype's project request is prepared on-device for copying; it is not sent to a server or automatically delivered. Portfolio and app-suite areas currently contain sample categories/planned entries.
